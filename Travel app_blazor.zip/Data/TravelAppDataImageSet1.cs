//namespace TravelApp.Data.TravelAppData; // Razor won't recognize third level namespace
namespace TravelApp.TravelAppData;

public class ImageSet1Type
{
    public string? Image_url { get; set; }
}
