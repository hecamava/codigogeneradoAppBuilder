//namespace TravelApp.Data.TravelAppData; // Razor won't recognize third level namespace
namespace TravelApp.TravelAppData;

public class ArticlesSource1Type
{
    public string? Title { get; set; }
    public string? Subtitle { get; set; }
    public string? Image_url { get; set; }
}
