//namespace TravelApp.Data.TravelAppData; // Razor won't recognize third level namespace
namespace TravelApp.TravelAppData;

public class DestinationsType
{
    public string? Title { get; set; }
    public string? Image_url { get; set; }
}
